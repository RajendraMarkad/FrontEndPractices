package com.cognizant.ptracker.exceptions;

public class PatientException extends Exception{

	private static final long serialVersionUID = -9079454849611061074L;

	public String errorMessage;

}
